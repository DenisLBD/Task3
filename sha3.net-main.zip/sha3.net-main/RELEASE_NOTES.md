
Release Notes
=============

## [2.0.0](https://github.com/dariogriffo/sha3.net/releases/tag/2.0.0)

**Important this is a breaking version**

Removed .NET framework targets 4.5 and 4.6
Removed dependency from [BouncyCastle.NetCore](https://www.nuget.org/packages/BouncyCastle.NetCore/) reducing execution time to 10% from the previous version.
The code from BouncyCastle.NetCore was introduced with the copyright as part of this project

Added net5.0 and net6.0 target frameworks.
